<?php

$con = new PDO("mysql:host=database-epgal.cinrt0cz5hud.us-east-1.rds.amazonaws.com;dbname=anime", "admin", "epgalcrede17") or die("Failed to connect to MySQL: " . mysqli_connect_error());